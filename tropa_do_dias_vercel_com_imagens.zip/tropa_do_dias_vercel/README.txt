TROPA DO DIAS — PROJETO PARA VERCEL

O site inclui uma galeria com as 10 imagens enviadas, a tabela de diamantes e botões para o grupo do WhatsApp.

PUBLICAR/ATUALIZAR NA VERCEL:
1. Envie a pasta do projeto para o repositório GitHub conectado à Vercel.
2. Confirme que index.html está na raiz e que a pasta assets contém as imagens.
3. A Vercel fará um novo deploy automaticamente após o envio ao GitHub.
4. Para publicação manual, importe a pasta completa; Framework Preset: Other; Build Command vazio; Output Directory vazio.
